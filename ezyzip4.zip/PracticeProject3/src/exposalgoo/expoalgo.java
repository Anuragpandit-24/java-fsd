package exposalgoo;
import java.util.*;
public class expoalgo {

	public static int exponentialSearch(int[] array, int target) {
        int n = array.length;

        // If the target is present at the first position
        if (array[0] == target) {
            return 0;
        }

        // Find the range for binary search by doubling the index
        int i = 1;
        while (i < n && array[i] <= target) {
            i *= 2;
        }

        // Perform binary search in the found range
        return binarySearch(array, target, i / 2, Math.min(i, n - 1));
    }

    public static int binarySearch(int[] array, int target, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (array[mid] == target) {
                return mid; // Element found, return its index
            } else if (array[mid] < target) {
                left = mid + 1; // Discard the left half
            } else {
                right = mid - 1; // Discard the right half
            }
        }

        return -1; // Element not found
    }

    public static void main(String[] args) {
        int[] sortedArray = {11, 28, 39, 60, 67, 243, 299, 345, 487};
        int target = 07;

        // Ensure the array is sorted
        Arrays.sort(sortedArray);

        int result = exponentialSearch(sortedArray, target);

        if (result != -1) {
            System.out.println("I am  " + target + " at index " + result);
        } else {
            System.out.println("Element " + target + " not found in the array.");
        }
    }

}
