package linearsdemo;

public class Lalgo {

	 public static int linearSearch(int[] array, int target) {
	        for (int i = 0; i < array.length; i++) {
	            if (array[i] == target) {
	                return i; // Element found, return its index
	            }
	        }
	        return -1; // Element not found
	    }

	    public static void main(String[] args) {
	        int[] array = {1, 5, 9, 2, 7, 3, 8, 4, 6};
	        int target = 7;

	        int result = linearSearch(array, target);

	        if (result != -1) {
	            System.out.println("Element " + target + " found at index " + result);
	        } else {
	            System.out.println("Element " + target + " not found in the array.");
	        }
	    }

}
