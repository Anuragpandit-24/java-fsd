package com.example;

import com.example.model.Address;
import com.example.model.Person;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainApp {

    public static void main(String[] args) {
        try (SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory()) {
            try (Session session = sessionFactory.openSession()) {
                Transaction transaction = session.beginTransaction();

                // Create a Person with an Address component
                Person person = new Person();
                person.setName("John Doe");

                Address address = new Address();
                address.setStreet("123 Main St");
                address.setCity("Cityville");
                address.setZipCode("12345");

                person.setAddress(address);

                // Save the Person entity with the embedded Address component
                session.save(person);

                transaction.commit();

                // Retrieve the Person entity and display the embedded Address
                Person retrievedPerson = session.get(Person.class, person.getId());
                if (retrievedPerson != null) {
                    System.out.println("Person Name: " + retrievedPerson.getName());
                    System.out.println("Address: " + retrievedPerson.getAddress().getStreet() +
                            ", " + retrievedPerson.getAddress().getCity() +
                            ", " + retrievedPerson.getAddress().getZipCode());
                }
            }
        }
    }

}
