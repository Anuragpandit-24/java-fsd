package com.example.dao;

import com.example.model.Person;

import java.util.List;


public interface PersonDAO {
	
	void savePerson(Person person);

    Person getPersonById(Long id);

    List<Person> getAllPersons();

    void updatePerson(Person person);

    void deletePerson(Long id);

}
