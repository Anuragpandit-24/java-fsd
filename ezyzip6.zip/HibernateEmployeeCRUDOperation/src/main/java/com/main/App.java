package com.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.Employee;
public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		System.out.println("File loaded sucessfully");
		
		SessionFactory sf = con.buildSessionFactory();	// like a Connection con;
		
		Session session = sf.openSession();        // Like a Statement as well as PreparedStatement
		
//		// Now we will create entity class object 
//		Employee emp1 = new Employee();
//		emp1.setId(102);
//		emp1.setName("Rajesh");
//		emp1.setSalary(18000);
//		
//		// Create Transaction object 
//					Transaction tran = session.getTransaction();
//					tran.begin();
//					
//						session.save(emp1);				// like a insert query 
//		
//					tran.commit();
//					
//					System.out.println("Record inserted successfully");
		
		// Delete query
		
//		    

//		
//		Employee emp2 = session.find(Employee.class, 10000);
//	    if(emp2 == null) {
//	    	System.out.println("Record not present");
//	    }else {
//	    	Transaction tran = session.getTransaction();
//	    	tran.begin();
//	    	session.delete(emp2);
//	    	tran.commit();
//	    	System.out.println("Record delete successfully");
//	    }
		
//		Employee emp2 = session.find(Employee.class, 101);
//	    if(emp2 == null) {
//	    	System.out.println("Record not present");
//	    }else {
//	    	Transaction tran = session.getTransaction();
//	    	tran.begin();
//	    	emp2.setSalary(250000);
//	    	session.update(emp2);
//	    	tran.commit();
//	    	System.out.println("Record Updated sucessfully ");
//	    }
		Employee emp2 = session.find(Employee.class, 1002);
	    if(emp2 == null) {
	    	System.out.println("Record not present");
	    }else {
	    	System.out.println(emp2);
	    	
	    }

	}

}
