package com.example;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Employee {
	private int id;
    private String name;
    private List<String> phoneNumbers;
    private Set<String> emails;
    private Map<String, String> attributes;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int id, String name, List<String> phoneNumbers, Set<String> emails,
			Map<String, String> attributes) {
		super();
		this.id = id;
		this.name = name;
		this.phoneNumbers = phoneNumbers;
		this.emails = emails;
		this.attributes = attributes;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getPhoneNumbers() {
		return phoneNumbers;
	}
	public void setPhoneNumbers(List<String> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}
	public Set<String> getEmails() {
		return emails;
	}
	public void setEmails(Set<String> emails) {
		this.emails = emails;
	}
	public Map<String, String> getAttributes() {
		return attributes;
	}
	public void setAttributes(Map<String, String> attributes) {
		this.attributes = attributes;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", phoneNumbers=" + phoneNumbers + ", emails=" + emails
				+ ", attributes=" + attributes + "]";
	}
    

}
