package com.example;

import com.example.model.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class MainApp {

	public static void main(String[] args) {
		
		try (SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory()) {
            // Create a new employee
			Employee employee = new Employee(1, "John Doe", 50000);

            // Save the employee to the database
            try (Session session = sessionFactory.openSession()) {
                session.beginTransaction();
                session.save(employee);
                session.getTransaction().commit();
            }

            // Retrieve the employee from the database
            try (Session session = sessionFactory.openSession()) {
                Employee retrievedEmployee = session.get(Employee.class, 1);
                System.out.println("Retrieved Employee: " + retrievedEmployee);
            }
        }
		// TODO Auto-generated method stub

	}

}
