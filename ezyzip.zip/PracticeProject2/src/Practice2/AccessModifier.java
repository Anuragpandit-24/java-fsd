package Practice2;

class DefaultAccessClass {
    void display() {
        System.out.println("Default Access Class");
    }
}

public class AccessModifier {
	
	

    // Public method
    public void publicMethod() {
        System.out.println("Public Method");
    }

    // Private method
    private void privateMethod() {
        System.out.println("Private Method");
    }

    // Protected method
    protected void protectedMethod() {
        System.out.println("Protected Method");
    }

    // Default (package-private) method
    void defaultMethod() {
        System.out.println("Default (Package-Private) Method");
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccessModifier example = new AccessModifier();

        // Accessing fields and methods from the same class
       
        example.publicMethod();
        example.privateMethod();    // This will result in a compilation error
        example.protectedMethod();
        example.defaultMethod();

        // Accessing default access class from the same package
        DefaultAccessClass defaultAccessClass = new DefaultAccessClass();
        defaultAccessClass.display();

	}

}
