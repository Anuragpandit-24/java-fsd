package PracticeProject3;

public class Methodandways {
	
	public void simpleMethod() {
        System.out.println("Simple method without parameters and without return value");
    }

    // Method with parameters and without return value
    public void methodWithParameters(String message) {
        System.out.println("Method with parameters: " + message);
    }

    // Method with parameters and with a return value
    public int add(int a, int b) {
        return a + b;
    }

    // Method with a return value and using the return statement
    public String getMessage() {
        return "Hello, this is a returned message.";
    }

	public static void main(String[] args) {
		
		Methodandways example = new Methodandways();

        // Calling a method without parameters and without return value
        example.simpleMethod();

        // Calling a method with parameters and without return value
        example.methodWithParameters("Hello from the main method!");

        // Calling a method with parameters and with a return value
        int result = example.add(5, 7);
        System.out.println("Result of addition: " + result);

        // Calling a method with a return value and using the return statement
        String message = example.getMessage();
        System.out.println("Returned message: " + message);

        // Another way to call a method with parameters and without return value
        example.methodWithParameters("Another message");

        

	}

}
