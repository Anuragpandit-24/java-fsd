package PracticeProject7;

class Outer {
	 
    // Class 2
    // Simple nested inner class
    class Inner {
 
        // show() method of inner class
        public void show()
        {
 
            // Print statement
            System.out.println("In a nested class method");
        }
    }
}

public class innerclasses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Outer.Inner in = new Outer().new Inner();
		 
		
		 
	        // Calling show() method over above object created
	        in.show();

	}

}
