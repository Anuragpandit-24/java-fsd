package PracticeProject10;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regular {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Pattern.matches(
	            "Anurag Pandit", "Anurag Pandit"));
	 
	        // Following line prints "false" because the whole
	        
	        System.out.println(
	            Pattern.matches("Diamond", "Gold"));
	}

}
