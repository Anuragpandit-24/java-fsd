package PracticeProject8;
import java.util.*;
import java.lang.*;

public class String {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub
		java.lang.String originalString = "Hello World!";

        // Convert String to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(originalString);

        // Convert String to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(originalString);

        // Display the original string
        System.out.println("Original String: " + originalString);

        // Display the StringBuffer
        System.out.println("StringBuffer: " + stringBuffer);

        // Display the StringBuilder
        System.out.println("StringBuilder: " + stringBuilder);

	}

}
