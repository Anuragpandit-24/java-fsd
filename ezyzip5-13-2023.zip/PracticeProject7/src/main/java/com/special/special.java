package com.special;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpServlet;

/**
 * Servlet implementation class special
 */
public class special extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    private void handleRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the existing session or create a new one
        HttpSession session = request.getSession(true);

        // Set response content type
        response.setContentType("text/html");

        // Create HTML response
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Session Tracking using URL Rewrite</title></head>");
        out.println("<body>");

        // Display session ID
        out.println("<h2>Session ID: " + session.getId() + "</h2>");
        out.println("<p>Refresh the page to see the same session ID.</p>");

        // Add a link to the same servlet with the session ID appended to the URL
        out.println("<p><a href=\"" + response.encodeURL(request.getRequestURI()) + "\">Reload with URL Rewriting</a></p>");

        out.println("</body>");
        out.println("</html>");
    }

}
