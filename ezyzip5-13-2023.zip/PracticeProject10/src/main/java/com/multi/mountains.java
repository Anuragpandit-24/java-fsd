package com.multi;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import jakarta.servlet.http.HttpServlet;

/**
 * Servlet implementation class mountains
 */
public class mountains extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // In a real application, you would validate the username and password against a database
        // For simplicity, we'll use a hardcoded username and password in this example
        if ("demoUser".equals(username) && "demoPassword".equals(password)) {
            // Successful login
            HttpSession session = request.getSession(true);
            session.setAttribute("username", username);

            response.sendRedirect("home.jsp"); // Redirect to the home page after successful login
        } else {
            // Failed login
            response.sendRedirect("login.jsp?error=true"); // Redirect to the login page with an error parameter
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("logout".equals(action)) {
            // Logout: Invalidate the session
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate();
            }
            response.sendRedirect("login.jsp"); // Redirect to the login page after logout
        } else {
            // Invalid action, redirect to login page
            response.sendRedirect("login.jsp");
        }
    }

}
