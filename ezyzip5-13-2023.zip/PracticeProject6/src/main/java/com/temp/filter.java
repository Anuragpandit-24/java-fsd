package com.temp;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServlet;

/**
 * Servlet implementation class filter
 */
public class filter extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    private void handleRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the existing session ID from the cookie
        String sessionId = null;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("sessionId".equals(cookie.getName())) {
                    sessionId = cookie.getValue();
                    break;
                }
            }
        }

        // If no session ID is found, create a new one
        if (sessionId == null) {
            sessionId = generateSessionId();
            // Create a new cookie and set it in the response
            Cookie sessionCookie = new Cookie("sessionId", sessionId);
            response.addCookie(sessionCookie);
        }

        // Set response content type
        response.setContentType("text/html");

        // Create HTML response
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Session Tracking using Cookies</title></head>");
        out.println("<body>");
        out.println("<h2>Session ID: " + sessionId + "</h2>");
        out.println("<p>Refresh the page to see the same session ID.</p>");
        out.println("</body>");
        out.println("</html>");
    }

    private String generateSessionId() {
        // A simple method to generate a unique session ID
        return "SESSION_" + System.currentTimeMillis();
    }

}
