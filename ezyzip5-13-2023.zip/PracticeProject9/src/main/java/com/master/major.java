package com.master;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpServlet;

/**
 * Servlet implementation class major
 */
public class major extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    private void handleRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the existing session or create a new one
        HttpSession session = request.getSession(true);

        // Set response content type
        response.setContentType("text/html");

        // Create HTML response
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Session Tracking using HttpSession</title></head>");
        out.println("<body>");

        // Display session ID
        out.println("<h2>Session ID: " + session.getId() + "</h2>");
        out.println("<p>Refresh the page to see the same session ID.</p>");

        // Store and retrieve data in the session
        String sessionDataKey = "counter";
        Integer counter = (Integer) session.getAttribute(sessionDataKey);
        if (counter == null) {
            counter = 1;
        } else {
            counter++;
        }

        session.setAttribute(sessionDataKey, counter);

        out.println("<p>Page Visits: " + counter + "</p>");

        out.println("</body>");
        out.println("</html>");
    }

}
