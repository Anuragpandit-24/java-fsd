package com.main;

import java.io.PrintWriter;
import java.io.IOException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServlet;

/**
 * Servlet implementation class makeit
 */
public class makeit extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        processRequest(request, response, "GET");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        processRequest(request, response, "POST");
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response, String method)
            throws IOException {
        // Set the response content type
        response.setContentType("text/html");

        // Get user input parameters from the request
        String name = request.getParameter("name");
        String email = request.getParameter("email");

        // Create HTML response
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Servlet GET vs POST Demo</title></head>");
        out.println("<body>");
        out.println("<h2>HTTP " + method + " Method</h2>");
        out.println("<p>Name: " + name + "</p>");
        out.println("<p>Email: " + email + "</p>");
        out.println("</body>");
        out.println("</html>");
    }

}
