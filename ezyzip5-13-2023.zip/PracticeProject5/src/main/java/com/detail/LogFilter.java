package com.detail;

import java.io.IOException;
import java.util.Date;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;


@WebFilter("/sprit")
public class LogFilter implements Filter {

    public void init(FilterConfig config) throws ServletException {
        // Initialization code goes here (if needed)
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        // Log information about the request
        System.out.println("Request received at: " + new Date());

        // Pass the request through the filter chain
        chain.doFilter(request, response);

        // Log information about the response (if needed)
        System.out.println("Response sent at: " + new Date());
    }

    public void destroy() {
        // Cleanup code goes here (if needed)
    }
}
