package com.specific;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpServlet;

/**
 * Servlet implementation class multi
 */
public class multi extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    private void handleRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the existing session or create a new one
        HttpSession session = request.getSession(true);

        // Set response content type
        response.setContentType("text/html");

        // Create HTML response
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Session Tracking using Hidden Form Fields</title></head>");
        out.println("<body>");

        // Display session ID
        out.println("<h2>Session ID: " + session.getId() + "</h2>");
        out.println("<p>Refresh the page to see the same session ID.</p>");

        // Create a form with a hidden field containing the session ID
        out.println("<form action=\"" + request.getRequestURI() + "\" method=\"post\">");
        out.println("<input type=\"hidden\" name=\"sessionId\" value=\"" + session.getId() + "\">");
        out.println("<input type=\"submit\" value=\"Submit Form\">");
        out.println("</form>");

        out.println("</body>");
        out.println("</html>");
    }

}
