package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class JDBCExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
try {
			
	Class.forName("com.mysql.cj.jdbc.Driver");

    // Establish a connection
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "92814603");

    // Execute a query
    String query = "SELECT * FROM employees";
    try (PreparedStatement preparedStatement = con.prepareStatement(query);
         ResultSet resultSet = preparedStatement.executeQuery()) {

        // Process the results
        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String name = resultSet.getString("name");
            double salary = resultSet.getDouble("salary");

            System.out.println("ID: " + id + ", Name: " + name + ", Salary: " + salary);
        }
    }

    // Close the connection
    con.close();
} catch (ClassNotFoundException | SQLException e) {
    e.printStackTrace();
}

	}

}
