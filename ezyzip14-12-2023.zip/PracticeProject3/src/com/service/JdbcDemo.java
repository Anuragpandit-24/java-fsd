package com.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class JdbcDemo {
	
	public static void main(String[] args) {
	String jdbcUrl = "jdbc:mysql://localhost:3306/demo_db";
    String username = "root";
    String password = "92814603";

    try {
        // Step 1: Register JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Step 2: Establish a connection
        Connection connection = DriverManager.getConnection(jdbcUrl, username, password);

        // Step 3: Create a statement
        Statement statement = connection.createStatement();

        // Step 4: Execute a query
        String selectQuery = "SELECT * FROM users";
        ResultSet resultSet = statement.executeQuery(selectQuery);

        // Step 5: Process the results
        while (resultSet.next()) {
            int userId = resultSet.getInt("id");
            String userName = resultSet.getString("username");
            String userPassword = resultSet.getString("password");

            System.out.println("User ID: " + userId + ", Username: " + userName + ", Password: " + userPassword);
        }

        // Step 6: Close resources
        resultSet.close();
        statement.close();
        connection.close();

    } catch (ClassNotFoundException | SQLException e) {
        e.printStackTrace();
    }
	}

}
