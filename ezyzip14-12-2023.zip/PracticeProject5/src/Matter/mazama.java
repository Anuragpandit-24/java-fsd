package Matter;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class mazama {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo_database", "root", "92814603");

            // Example 1: Using Statement to execute a simple query
            Statement statement = con.createStatement();
            String query1 = "SELECT * FROM users";
            ResultSet resultSet1 = statement.executeQuery(query1);

            // Process the results of query1
            while (resultSet1.next()) {
                int userId = resultSet1.getInt("id");
                String username = resultSet1.getString("username");
                String password = resultSet1.getString("password");

                System.out.println("User ID: " + userId + ", Username: " + username + ", Password: " + password);
            }

            // Example 2: Using PreparedStatement to execute a parameterized query
            int parameterValue = 42; // Replace with your actual parameter value
            String query2 = "SELECT * FROM users WHERE id = ?";
            PreparedStatement preparedStatement = con.prepareStatement(query2);
            preparedStatement.setInt(1, parameterValue);
            ResultSet resultSet2 = preparedStatement.executeQuery();

            // Process the results of query2
            while (resultSet2.next()) {
                int userId = resultSet2.getInt("id");
                String username = resultSet2.getString("username");
                String password = resultSet2.getString("password");

                System.out.println("User ID: " + userId + ", Username: " + username + ", Password: " + password);
            }

            // Close resources
            resultSet1.close();
            statement.close();
            resultSet2.close();
            preparedStatement.close();
            con.close();

        } catch (ClassNotFoundException | SQLException e) {
            // Handle exceptions (customize this based on your requirements)
            e.printStackTrace();
        }

	}

}
