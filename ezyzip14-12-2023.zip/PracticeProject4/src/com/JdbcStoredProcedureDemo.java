package com;

import java.sql.*;

public class JdbcStoredProcedureDemo {
	
	 public static void main(String[] args) {
	        // JDBC connection parameters
	        String jdbcUrl = "jdbc:mysql://localhost:3306/demo_db";
	        String username = "root";
	        String password = "92814603";

	        try {
	            // Step 1: Register JDBC driver
	            Class.forName("com.mysql.cj.jdbc.Driver");

	            // Step 2: Establish a connection
	            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);

	            // Step 3: Prepare and call the stored procedure
	            String callProcedure = "{CALL get_user(?, ?, ?)}";
	            CallableStatement callableStatement = connection.prepareCall(callProcedure);

	            // Set input parameter (user ID)
	            int userId = 1;
	            callableStatement.setInt(1, userId);

	            // Set output parameters
	         // Set output parameters
	            callableStatement.registerOutParameter(1, Types.VARCHAR); // userName
	            callableStatement.registerOutParameter(2, Types.VARCHAR); // userPassword


	            // Execute the stored procedure
	            callableStatement.execute();

	            // Step 4: Process the results
	            String userName = callableStatement.getString(2);
	            String userPassword = callableStatement.getString(3);

	            System.out.println("User ID: " + userId + ", Username: " + userName + ", Password: " + userPassword);

	            // Step 5: Close resources
	            callableStatement.close();
	            connection.close();

	        } catch (ClassNotFoundException | SQLException e) {
	            // Handle exceptions
	            e.printStackTrace();
	        }
	    }

}
