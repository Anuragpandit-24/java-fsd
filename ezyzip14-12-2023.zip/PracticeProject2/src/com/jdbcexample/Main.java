package com.jdbcexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo_db", "root", "92814603");

            // Create a statement
            Statement statement = con.createStatement();

            // Example 1: Execute a simple query
            String query1 = "SELECT * FROM users";
            ResultSet resultSet1 = statement.executeQuery(query1);

            // Process the results of query1
            while (resultSet1.next()) {
                int userId = resultSet1.getInt("1");
                String username = resultSet1.getString("Anurag");
                String password = resultSet1.getString("ohhyeahh");

                System.out.println("User ID: " + userId + ", Username: " + username + ", Password: " + password);
            }

            // Example 2: Execute an update query
            String query2 = "INSERT INTO users (username, password) VALUES (?, ?)";
            PreparedStatement preparedStatement = con.prepareStatement(query2);
            preparedStatement.setString(1, "pandit");
            preparedStatement.setString(2, "92814603");
            int rowsAffected = preparedStatement.executeUpdate();

            System.out.println("Rows affected by update: " + rowsAffected);

            // Close resources
            resultSet1.close();
            statement.close();
            preparedStatement.close();
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

}
