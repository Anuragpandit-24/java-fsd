package smallest;

import java.util.*;

public class fourth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] unsortedList = {10, 5, 8, 1, 7, 3, 9, 2, 6, 4};

        int fourthSmallest = findFourthSmallestElement(unsortedList);

        System.out.println("Unsorted List: " + Arrays.toString(unsortedList));
        System.out.println("Fourth Smallest Element: " + fourthSmallest);
    }

    private static int findFourthSmallestElement(int[] arr) {
        if (arr.length < 4) {
            // Handle cases where the array has less than four elements
            System.out.println("Array should have at least four elements.");
            return -1; // or throw an exception
        }

        // Sort the array in ascending order
        Arrays.sort(arr);

        // Return the fourth smallest element
        return arr[3];

	}

}
