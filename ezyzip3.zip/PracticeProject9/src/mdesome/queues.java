package mdesome;

import java.util.LinkedList;
import java.util.Queue;

public class queues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Queue<Integer> queue = new LinkedList<>();

        // Enqueue elements into the queue
        queue.add(10);
        queue.add(20);
        queue.add(30);
        queue.add(45);
        queue.add(99);
        //one method to remove the first element
        queue.poll();

        System.out.println("Queue after enqueuing elements: " + queue);

        // Dequeue an element from the queue
        int dequeuedElement = queue.poll();
        System.out.println("Dequeued element: " + dequeuedElement);
        System.out.println("Queue after dequeuing an element: " + queue);

        // Peek at the front element without removing it
        int frontElement = queue.peek();
        System.out.println("Front element (without removing): " + frontElement);
        System.out.println("Queue after peeking: " + queue);
		

	}

}
