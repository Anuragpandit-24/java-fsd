package ranges;

import java.util.*;

public class range {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);

        // Input the size of the array
        System.out.print("Enter the size of the array (n): ");
        int n = scanner.nextInt();

        // Input the elements of the array
        int[] array = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }

        // Input the range (L and R)
        System.out.print("Enter the value of L (0 <= L <= R <= n-1): ");
        int L = scanner.nextInt();
        System.out.print("Enter the value of R (0 <= L <= R <= n-1): ");
        int R = scanner.nextInt();

        // Validate the input range
        if (L < 0 || R < L || R >= n) {
            System.out.println("Invalid input range. Please make sure 0 <= L <= R <= n-1.");
        } else {
            // Calculate and print the sum of elements in the specified range
            int sum = calculateSumInRange(array, L, R);
            System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
        }

        scanner.close();
    }

    private static int calculateSumInRange(int[] arr, int L, int R) {
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        return sum;

	}

}
